COPY        START    1000
FIRST       LDA      FIVE
            ADD      ONE
            STA      RESULT
            LDA      BUFFER,X
FIVE        WORD     3
ONE         WORD     1
RESULT      RESW     1
BUFFER      RESB     10
HEX1        BYTE     X'F1'
CHAR1       BYTE     C'EOF'
            END      FIRST