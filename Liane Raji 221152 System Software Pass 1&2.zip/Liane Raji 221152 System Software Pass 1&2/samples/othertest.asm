TEST        START    1000
FIRST       ADD      WRONG,XZ
            SUB
            STA      123ABC
            LDA      =C'EOF'
            END      FIRST